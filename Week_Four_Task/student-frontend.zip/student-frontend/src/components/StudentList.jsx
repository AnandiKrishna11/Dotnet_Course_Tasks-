import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import api from "../api";

const StudentList = () => {
  const [students, setStudents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [message, setMessage] = useState('');
  const navigate = useNavigate();

  const token = localStorage.getItem("token");
  const isAuthenticated = !!token;

  const fetchStudents = async () => {
    try {
      const response = await api.get("/Student");
      setStudents(response.data);
    } catch (err) {
      setError("Failed to load students. Please check your backend connection.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStudents();
  }, []);

  const handleDelete = async (studentId) => {
    if (!isAuthenticated) {
      setMessage('You must be logged in to delete a student.');
      return;
    }
    if (window.confirm("Are you sure you want to delete this student?")) {
      try {
        await api.delete(`/Student/${studentId}`);
        setStudents(students.filter(student => student.studentId !== studentId));
        setMessage('Student deleted successfully!');
      } catch (err) {
        setMessage("Failed to delete student: " + (err.response?.data?.message || err.message));
      }
    }
  };

  const handleLogout = () => {
    localStorage.removeItem("token"); 
    navigate("/"); 
    window.location.reload(); 
  };

  if (loading) return <div className="container">Loading students...</div>;

  return (
    <div className="container">
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <h2>Student List</h2>
        {isAuthenticated && (
          <button onClick={handleLogout} className="btn btn-primary">Logout</button> 
        )}
      </div>

      {isAuthenticated && (
        <div style={{ marginBottom: '20px' }}>
          <button onClick={() => navigate("/add")} className="btn btn-primary">Add Student</button>
        </div>
      )}

      {error && <div className="message-box error">{error}</div>}
      {message && <div className={`message-box ${message.includes('successfully') ? 'success' : 'error'}`}>{message}</div>}

      {students.length === 0 ? (
        <p>No students found.</p>
      ) : (
        <table className="student-table">
          <thead>
            <tr>
              <th>Name</th>
              <th>Age</th>
              <th>Grade</th>
              {isAuthenticated && <th>Actions</th>}
            </tr>
          </thead>
          <tbody>
            {students.map((student) => (
              <tr key={student.studentId}>
                <td>{student.name}</td>
                <td>{student.age}</td>
                <td>{student.grade}</td>
                {isAuthenticated && (
                  <td>
                    <Link to={`/edit/${student.studentId}`} className="btn btn-secondary">Edit</Link>
                    <button onClick={() => handleDelete(student.studentId)} className="btn btn-danger">Delete</button>
                  </td>
                )}
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default StudentList;
