import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import api from '../api';

const EditStudent = () => {
  const { id } = useParams();
  const navigate = useNavigate();

  const [student, setStudent] = useState({ StudentId: 0, Name: '', Age: '', Grade: '' });
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState('');

  useEffect(() => {
    const fetchStudent = async () => {
      try {
        const response = await api.get(`/Student/${id}`);
        setStudent(response.data);
      } catch (error) {
        setMessage('Failed to fetch student details. Redirecting...');
        setTimeout(() => navigate('/students'), 1500);
      } finally {
        setLoading(false);
      }
    };
    fetchStudent();
  }, [id, navigate]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setStudent(prevStudent => ({
      ...prevStudent,
      [name]: name === 'Age' ? Number(value) : value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setMessage('');
    try {
      await api.put(`/Student/${id}`, student);
      setMessage('Student updated successfully!');
      setTimeout(() => navigate('/students'), 1500);
    } catch (error) {
      setMessage('Failed to update student: ' + (error.response?.data?.message || error.message));
    }
  };

  if (loading) {
    return <div className="container">Loading...</div>;
  }

  return (
    <div className="container form-container">
    
      <button
        className="btn btn-primary"
        onClick={() => navigate('/students')}
        style={{ marginBottom: "15px" }}
      >
        ← Back to Student List
      </button>

      <h2>Edit Student</h2>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          name="Name"
          value={student.Name}
          onChange={handleChange}
          placeholder="Name"
          className="form-control"
          required
        />
        <input
          type="number"
          name="Age"
          value={student.Age ?? ''}
          onChange={handleChange}
          placeholder="Age"
          className="form-control"
          required
        />
        <input
          type="text"
          name="Grade"
          value={student.Grade}
          onChange={handleChange}
          placeholder="Grade"
          className="form-control"
          required
        />
        <button type="submit" className="btn btn-primary">Update Student</button>
      </form>
      {message && (
        <div className={`message-box ${message.includes('successfully') ? 'success' : 'error'}`}>
          {message}
        </div>
      )}
    </div>
  );
};

export default EditStudent;
