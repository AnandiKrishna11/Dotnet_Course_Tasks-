import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../api';

const AddStudent = () => {
    const [student, setStudent] = useState({ name: '', age: '', grade: '' });
    const [message, setMessage] = useState('');
    const navigate = useNavigate();

    const handleChange = (e) => {
        const { name, value } = e.target;
        setStudent(prevStudent => ({ ...prevStudent, [name]: value }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setMessage('');
        try {
            await api.post('/Student', student);
            setMessage('Student added successfully!');
            setTimeout(() => navigate('/students'), 1500);
        } catch (error) {
            setMessage('Failed to add student: ' + (error.response?.data?.message || error.message));
        }
    };

    return (
        <div className="container form-container">
         
            <button
                className="btn btn-primary"
                onClick={() => navigate('/students')}
                style={{ marginBottom: "15px" }}
            >
                ← Back to Student List
            </button>

            <h2>Add New Student</h2>
            <form onSubmit={handleSubmit}>
                <input
                    type="text"
                    name="name"
                    value={student.name}
                    onChange={handleChange}
                    placeholder="Name"
                    className="form-control"
                    required
                />
                <input
                    type="number"
                    name="age"
                    value={student.age}
                    onChange={handleChange}
                    placeholder="Age"
                    className="form-control"
                    required
                />
                <input
                    type="text"
                    name="grade"
                    value={student.grade}
                    onChange={handleChange}
                    placeholder="Grade"
                    className="form-control"
                    required
                />
                <button type="submit" className="btn btn-primary">Add Student</button>
            </form>
            {message && (
                <div className={`message-box ${message.includes('successfully') ? 'success' : 'error'}`}>
                    {message}
                </div>
            )}
        </div>
    );
};

export default AddStudent;
