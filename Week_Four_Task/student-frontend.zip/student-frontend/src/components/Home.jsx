import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../api';

function Home() {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [message, setMessage] = useState('');
    const navigate = useNavigate();

    const handleSubmit = async (e) => {
        e.preventDefault();
        setMessage(''); 
        try {
          
            const response = await api.post('/Auth/login', { username, password });
            localStorage.setItem('token', response.data.token);
            setMessage('Login successful!');
            navigate('/students'); 
        } catch (error) {
            setMessage('Login failed. Invalid username or password.');
        }
    };

    return (
        <div className="container form-container">
            <h2>Admin Login</h2>
            <form onSubmit={handleSubmit}>
                <input
                    type="text"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="Username"
                    className="form-control"
                    required
                />
                <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Password"
                    className="form-control"
                    required
                />
                <button type="submit" className="btn btn-primary">Login</button>
            </form>
            {message && <div className={`message-box ${message.includes('successful') ? 'success' : 'error'}`}>{message}</div>}
           
        </div>
    );
}

export default Home;