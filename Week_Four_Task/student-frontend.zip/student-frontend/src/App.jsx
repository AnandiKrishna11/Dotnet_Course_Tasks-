import React from "react";
import { Routes, Route, useNavigate } from "react-router-dom";
import Home from "./components/Home.jsx";
import StudentList from "./components/StudentList.jsx";
import AddStudent from "./components/AddStudent.jsx";
import EditStudent from "./components/EditStudent.jsx";
import ProtectedRoute from "./components/ProtectedRoute.jsx";

const Header = () => {
    const navigate = useNavigate();
    const token = localStorage.getItem("token");

    const handleLogout = () => {
        localStorage.removeItem("token");
        navigate("/");

        window.location.reload(); 
    };

    return (
        <header className="app-header">
            <h1>Student Management Portal</h1>
        </header>
    );
};

function App() {
  return (
    <>
      <Header />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/students" element={<StudentList />} />
       
        <Route path="/add" element={<ProtectedRoute><AddStudent /></ProtectedRoute>} />
        <Route path="/edit/:id" element={<ProtectedRoute><EditStudent /></ProtectedRoute>} />
      </Routes>
    </>
  );
}

export default App;